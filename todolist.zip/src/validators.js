import * as yup from "yup"

export const descriptionValidator = yup.string().label("Description")
